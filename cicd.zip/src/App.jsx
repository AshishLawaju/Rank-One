const App = () => {
  return (
    <div className="text-4xl p-10">
      <div className="text-[22px]">hello world</div>
      App{" "}

      <div>
        build 2
      </div>
    </div>
  );
};

export default App;
